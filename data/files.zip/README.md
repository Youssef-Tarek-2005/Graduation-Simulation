# ESP32-CAM Honeypot (Simulated)

Run:
    pip install -r requirements.txt
    python app.py

Then visit http://localhost:8080

Default (weak, intentional) credentials: admin / admin123

Endpoints:
- GET  /            dashboard (requires login)
- GET  /login       login page
- POST /login       submit credentials
- GET  /logout      end session
- GET  /stream      fake MJPEG stream
- GET  /snapshot    fake JPEG snapshot
- GET  /config      view settings (requires login)
- POST /config      change settings (requires login)
- GET  /status      device/firmware info
- POST /update      firmware update endpoint (any payload accepted + logged)

All activity is logged as JSON lines to ../logs/camera_honeypot.jsonl
