"""
Fake ESP32-CAM Honeypot
Mimics a real ESP32-CAM web interface to attract and log attacker interactions.
"""

from flask import Flask, request, session, redirect, url_for, jsonify, Response
import json
import time
import os
from datetime import datetime, timezone
import uuid
import socket
import threading

app = Flask(__name__)
app.secret_key = "esp32cam-honeypot-fixed-key"  # intentionally weak, this is a honeypot

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
DEVICE_ID = "ESP32CAM-01"
VALID_USERNAME = "admin"
VALID_PASSWORD = "admin123"   # deliberately weak default credential
LOG_FILE = os.path.join(os.path.dirname(__file__), "..", "logs", "camera_honeypot.jsonl")
os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)

# In-memory state (mutable "device settings" an attacker can tamper with)
device_state = {
    "resolution": "VGA(640x480)",
    "quality": 10,
    "brightness": 0,
    "password": VALID_PASSWORD,
    "firmware_version": "1.0.3",
}

# simple in-memory rate tracking for DoS / brute-force detection support
request_counters = {}  # ip -> list of timestamps
failed_logins = {}     # ip -> list of timestamps

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------
def log_event(event_type, outcome="info", extra=None):
    """
    Writes a single structured log line for every interaction.
    This is the raw data that later feeds the storage layer and AI pipeline.
    """
    entry = {
        "log_id": str(uuid.uuid4()),
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "device_id": DEVICE_ID,
        "device_type": "esp32-cam",
        "src_ip": request.remote_addr,
        "method": request.method,
        "path": request.path,
        "user_agent": request.headers.get("User-Agent", ""),
        "event_type": event_type,     # e.g. login_attempt, stream_access, config_change
        "outcome": outcome,           # success, fail, info
        "authenticated": session.get("logged_in", False),
        "extra": extra or {},
    }
    with open(LOG_FILE, "a") as f:
        f.write(json.dumps(entry) + "\n")
    return entry


def track_rate(counter_dict, ip, window_seconds=60):
    """Keeps a rolling timestamp list per IP, used for brute-force / DoS signal."""
    now = time.time()
    counter_dict.setdefault(ip, [])
    counter_dict[ip] = [t for t in counter_dict[ip] if now - t < window_seconds]
    counter_dict[ip].append(now)
    return len(counter_dict[ip])


# ---------------------------------------------------------------------------
# Fake outbound "C2 beacon" (simulates A11 / S11 command-and-control channel)
# Runs only if honeypot is "compromised" (a flag set via /update abuse)
# ---------------------------------------------------------------------------
compromised = {"flag": False}

def c2_beacon_loop():
    while True:
        if compromised["flag"]:
            log_event("c2_beacon", outcome="info",
                      extra={"note": "simulated outbound beacon to attacker C2"})
        time.sleep(15)

threading.Thread(target=c2_beacon_loop, daemon=True).start()


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------

@app.route("/")
def dashboard():
    """Root dashboard - mimics real ESP32-CAM landing page (Normal Activity #1)."""
    log_event("dashboard_access", outcome="success" if session.get("logged_in") else "unauthenticated")
    if not session.get("logged_in"):
        return redirect(url_for("login"))
    return f"""
    <html><head><title>ESP32-CAM</title></head>
    <body style="font-family:monospace;background:#111;color:#0f0;padding:20px;">
    <h2>ESP32-CAM Web Server</h2>
    <p>Device: {DEVICE_ID} | Firmware: {device_state['firmware_version']}</p>
    <ul>
      <li><a style="color:#0f0" href="/stream">Live Stream</a></li>
      <li><a style="color:#0f0" href="/snapshot">Take Snapshot</a></li>
      <li><a style="color:#0f0" href="/config">Settings</a></li>
      <li><a style="color:#0f0" href="/status">Device Status</a></li>
      <li><a style="color:#0f0" href="/logout">Logout</a></li>
    </ul>
    </body></html>
    """


@app.route("/login", methods=["GET", "POST"])
def login():
    """
    Auth endpoint. Supports Normal Activity #2 (normal login) and
    A3 Brute Force / A4 Session Hijacking detection signal.
    """
    if request.method == "GET":
        return """
        <html><body style="font-family:monospace;background:#111;color:#0f0;padding:20px;">
        <h3>ESP32-CAM Login</h3>
        <form method="POST">
          Username: <input name="username"><br>
          Password: <input name="password" type="password"><br>
          <button type="submit">Login</button>
        </form>
        </body></html>
        """

    username = request.form.get("username", "")
    password = request.form.get("password", "")
    ip = request.remote_addr

    if username == VALID_USERNAME and password == device_state["password"]:
        session["logged_in"] = True
        session["session_id"] = str(uuid.uuid4())
        log_event("login_attempt", outcome="success",
                  extra={"username": username})
        return redirect(url_for("dashboard"))
    else:
        attempts_last_min = track_rate(failed_logins, ip)
        log_event("login_attempt", outcome="fail",
                  extra={"username": username, "attempts_last_60s": attempts_last_min})
        return "Login failed", 401


@app.route("/logout")
def logout():
    """Normal Activity #6 - session termination."""
    log_event("logout", outcome="success")
    session.clear()
    return redirect(url_for("login"))


@app.route("/stream")
def stream():
    """
    Normal Activity #3 (watch stream) / A5 Live Stream Access Abuse.
    Real ESP32-CAM serves MJPEG; here we simulate with a placeholder response
    and just log every access, which is what matters for detection.
    """
    ip = request.remote_addr
    count = track_rate(request_counters, ip)
    log_event("stream_access", outcome="success" if session.get("logged_in") else "unauthorized",
              extra={"requests_last_60s": count})

    def fake_mjpeg():
        boundary = b"--frame\r\n"
        header = b"Content-Type: image/jpeg\r\n\r\n"
        fake_frame = b"\xff\xd8\xff\xd9"  # minimal valid-looking JPEG bytes stub
        for _ in range(5):
            yield boundary + header + fake_frame + b"\r\n"
            time.sleep(0.5)

    return Response(fake_mjpeg(), mimetype="multipart/x-mixed-replace; boundary=frame")


@app.route("/snapshot")
def snapshot():
    """
    Normal Activity #4 (capture snapshot) / A6 Image Data Exfiltration.
    Repeated rapid requests here are the anomaly signal.
    """
    ip = request.remote_addr
    count = track_rate(request_counters, ip)
    log_event("snapshot_access", outcome="success" if session.get("logged_in") else "unauthorized",
              extra={"requests_last_60s": count})
    fake_image_bytes = b"\xff\xd8\xff\xd9"
    return Response(fake_image_bytes, mimetype="image/jpeg")


@app.route("/config", methods=["GET", "POST"])
def config():
    """
    Normal Activity #5 (change settings) / A7 Camera Configuration Tampering.
    """
    if not session.get("logged_in"):
        log_event("config_access", outcome="unauthorized")
        return "Unauthorized", 401

    if request.method == "GET":
        return jsonify(device_state)

    changes = request.get_json(silent=True) or request.form.to_dict()
    device_state.update(changes)
    log_event("config_change", outcome="success", extra={"changes": changes})
    return jsonify(device_state)


@app.route("/status")
def status():
    """
    Device/firmware info endpoint - supports A8 Firmware Fingerprinting detection.
    Deliberately mimics a real ESP32-CAM minimal status response.
    """
    log_event("status_check", outcome="info")
    return jsonify({
        "device_id": DEVICE_ID,
        "firmware_version": device_state["firmware_version"],
        "uptime_seconds": int(time.time()) % 100000,
        "resolution": device_state["resolution"],
    })


@app.route("/update", methods=["POST"])
def update():
    """
    Firmware update endpoint - supports A9 Firmware Update Abuse.
    Any POST here is logged as a highly suspicious event and flips the
    'compromised' flag used by the fake C2 beacon (A11 simulation).
    """
    payload_size = request.content_length or 0
    log_event("firmware_update_attempt", outcome="suspicious",
              extra={"payload_size": payload_size})
    compromised["flag"] = True
    return jsonify({"status": "update received", "result": "processing"}), 202


# ---------------------------------------------------------------------------
# Catch-all for scanning / enumeration detection (A1, A2)
# Any path not defined above still gets logged.
# ---------------------------------------------------------------------------
@app.errorhandler(404)
def not_found(e):
    ip = request.remote_addr
    count = track_rate(request_counters, ip, window_seconds=30)
    log_event("probe_unknown_path", outcome="scan_suspect",
              extra={"requests_last_30s": count})
    return "Not Found", 404


if __name__ == "__main__":
    print(f"[+] Fake ESP32-CAM honeypot starting on http://0.0.0.0:8080")
    print(f"[+] Logging to: {LOG_FILE}")
    app.run(host="0.0.0.0", port=8080, debug=False)
